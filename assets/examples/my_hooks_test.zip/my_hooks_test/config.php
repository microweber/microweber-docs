<?php

$config = array();
$config['name'] = "My module";
$config['author'] = "Microweber";
$config['description'] = "Microweber";
$config['website'] = "http://microweber.com/"; 
$config['help'] = "http://microweber.com"; 
$config['version'] = 0.1;
$config['ui'] = true;
$config['ui_admin'] = true;
$config['categories'] = "content";
$config['position'] = 100; 



