<?php
/* Live edit hooks */



action_hook('live_edit_toolbar_menu_start', 'live_edit_toolbar_menu_start_test_hook');
function live_edit_toolbar_menu_start_test_hook($params = false)
{
    $html = '
    <li class="create-content-dropdown mw-toolbar-btn-menu">
    <a href="javascript:;" class="mw-ui-btn mw-ui-btn-medium">
    <span class="ico iplus"></span>
   Other menu
    </a>';
    print $html;
}



action_hook('live_edit_toolbar_menu_end', 'live_edit_toolbar_menu_end_test_hook');
function live_edit_toolbar_menu_end_test_hook($params = false)
{
    $menu = '
    <li class="create-content-dropdown mw-toolbar-btn-menu">
    <a href="javascript:;" class="mw-ui-btn mw-ui-btn-medium">
    <span class="ico iplus"></span>
    My menu
    </a>';
    print $menu;
}

action_hook('live_edit_quick_add_menu_end', 'live_edit_quick_add_menu_end_test_hook');
function live_edit_quick_add_menu_end_test_hook($params = false)
{
    $menu = '<li>
    <a href="javascript:;" onclick="mw.quick.category();">
    <span class="mw-ui-btn-plus left"></span><span class="ico icategory"></span>Hi!</a>
    </li>';
    print $menu;
}


action_hook('live_edit_toolbar_action_buttons', 'live_edit_toolbar_action_buttons_test_hook');
function live_edit_toolbar_action_buttons_test_hook($params = false)
{
    $html = '<span class="mw-ui-btn mw-ui-btn-medium mw-ui-btn-green mw-ui-btn"
        onclick="mw.drag.save(this)" id="my-save-btn">My Save</span>';
    print $html;

}

action_hook('live_edit_toolbar_action_menu_start', 'live_edit_toolbar_action_menu_start_test_hook');
function live_edit_toolbar_action_menu_start_test_hook($params = false)
{
    $html = '<li><a href="#"><span class="ico"></span><span>Click me</span></a> </li>';
    print $html;

}

action_hook('live_edit_toolbar_action_menu_middle', 'live_edit_toolbar_action_menu_middle_test_hook');
function live_edit_toolbar_action_menu_middle_test_hook($params = false)
{
    $html = '<li><a href="#"><span class="ico"></span><span>Yes Click me</span></a> </li>';
    print $html;

}

action_hook('live_edit_toolbar_action_menu_end', 'live_edit_toolbar_action_menu_end_test_hook');
function live_edit_toolbar_action_menu_end_test_hook($params = false)
{
    $html = '<li><a href="#"><span class="ico"></span><span>Hello!</span></a> </li>';
    print $html;

}

action_hook('live_edit_toolbar_controls', 'live_edit_toolbar_sections_start_test_hook');
function live_edit_toolbar_sections_start_test_hook($params = false)
{
     print 'live_edit_toolbar_controls hook';
}




action_hook('live_edit_toolbar_end', 'live_edit_toolbar_end_test_hook');
function live_edit_toolbar_end_test_hook($params = false)
{
     print 'live_edit_toolbar_end hook is here';
}


/* END OF Live edit hooks */




/* Admin Hooks */

action_hook('admin_head', 'admin_head_test_hook');
function admin_head_test_hook($params = false)
{
    $module_folder = __DIR__;
    $module_js = dir2url($module_folder . DS . 'my_module.js');
    $module_css = dir2url($module_folder . DS . 'my_module.css');

    $output = "<script src='{$module_js}'></script>" . "\n";
    $output .= "<link href='{$module_css}' rel='stylesheet'>" . "\n";
    print $output;
}




action_hook('admin_header_menu', 'admin_header_menu_test_hook');
function admin_header_menu_test_hook($params = false)
{
    $admin_url = admin_url('view:modules/load_module:my_hooks_test');
    $html = '<li><a title="Test" href="'.$admin_url.'">
    <i class="ico itabpic"></i><span>My admin button</span></a></li>';
    print $html;
}




action_hook('admin_content_right_sidebar_menu_list_start', 'admin_content_right_sidebar_menu_list_start_test_hook');
function admin_content_right_sidebar_menu_list_start_test_hook($params = false)
{
    $admin_url = admin_url('view:modules/load_module:my_hooks_test');
    $html = '<li><a title="Test" href="'.$admin_url.'">
    <i class="ico itabpic"></i><span>My custom button</span></a></li>';
    print $html;
}


action_hook('admin_content_side_menu_start', 'admin_content_side_menu_start_test_hook');
function admin_content_side_menu_start_test_hook($params = false)
{


}

action_hook('live_edit_toolbar_btn', 'live_edit_toolbar_btn_test_hook');
function live_edit_toolbar_btn_test_hook($params = false)
{
    $html ='<div class="wysiwyg-cell">
    <span class="mw_editor_btn mw_editor_bold" data-command="bold" title="Click me">
    <span class="ed-ico"></span>
    </span>
    </div>
    ';
    print $html;

}

















/* Front end hooks */
action_hook('on_load', 'my_on_load_test_hook');

function my_on_load_test_hook($params = false)
{
    if (isset($params['id']) and $params['id'] != false) {
        // somebody viewed content
    }
    return $params;
}


action_hook('site_header', 'my_site_header_test_hook');
function my_site_header_test_hook($params = false)
{
    $module_folder = __DIR__;
    $module_js = dir2url($module_folder . DS . 'my_module.js');
    $module_css = dir2url($module_folder . DS . 'my_module.css');

    $output = "<script src='{$module_js}'></script>" . "\n";
    $output .= "<link href='{$module_css}' rel='stylesheet'>" . "\n";
    return $output;
}






 
 