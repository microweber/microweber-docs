<h2>Font color</h2>

<!-- put mw_option_field class to an input element if you want it to be saved on change -->

<input name="color" type="text" class="mw_option_field"  value="<?php print get_option('color', $params['id']) ?>" />
