<?php $color = get_option('color', $params['id']) ?>
<h1 style="color:<?php print $color; ?>">Hello, I am a new module!</h1>