<?php 

function my_module_can_have_functions($params=false){
	return get_posts($params);
}


 